from .fcn_head import FCNHead
from .fouc_head import FOUCHead

__all__ = [
    'FCNHead','FOUCHead'
]
