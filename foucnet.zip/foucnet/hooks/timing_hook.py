import time
from mmcv.runner import Hook

class TimingHook(Hook):
    def __init__(self):
        self.times = []

    def before_test_iter(self, runner):
        self.start_time = time.time()

    def after_test_iter(self, runner):
        elapsed_time = time.time() - self.start_time
        self.times.append(elapsed_time)

    def after_test_epoch(self, runner):
        avg_time = sum(self.times) / len(self.times)
        runner.logger.info(f'Average inference time per image: {avg_time:.4f} seconds')

