# Copyright (c) OpenMMLab. All rights reserved.
import os.path as osp

from .builder import DATASETS
from .custom import CustomDataset


@DATASETS.register_module()
class u_crack(CustomDataset):

    CLASSES = ('background','crack')

    PALETTE = [[0, 0,0], [255, 255,255]]

    def __init__(self, **kwargs):
        super(u_crack, self).__init__(
            img_suffix='.jpg',
            seg_map_suffix='.png',
            reduce_zero_label=False,
            **kwargs)
        assert osp.exists(self.img_dir)

