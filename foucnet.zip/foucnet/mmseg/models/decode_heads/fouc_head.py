# Copyright (c) OpenMMLab. All rights reserved.
import torch
import torch.nn as nn
from mmcv.cnn import ConvModule

from mmseg.ops import resize
from ..builder import HEADS
from .decode_head import BaseDecodeHead
from .psp_head import PPM
from S3_DSConv import My_DSConv
from S3_DSConv import DSConv
BatchNorm2d = nn.BatchNorm2d
BatchNorm1d = nn.BatchNorm1d

@HEADS.register_module()
class FOUCHead(BaseDecodeHead):
    """Unified Perceptual Parsing for Scene Understanding.

    This head is the implementation of `UPerNet
    <https://arxiv.org/abs/1807.10221>`_.

    Args:
        pool_scales (tuple[int]): Pooling scales used in Pooling Pyramid
            Module applied on the last feature. Default: (1, 2, 3, 6).
    """

    def __init__(self,  **kwargs):
        super(FOUCHead, self).__init__(
            input_transform='multiple_select', **kwargs)
        # PSP Module

        # FPN Module
        self.lateral_convs = nn.ModuleList()
        self.fpn_convs = nn.ModuleList()
        for in_channels in self.in_channels:  # skip the top layer
            l_conv = ConvModule(
                in_channels,
                self.channels,
                1,
                conv_cfg=self.conv_cfg,
                norm_cfg=self.norm_cfg,
                act_cfg=self.act_cfg,
                inplace=False)
            fpn_conv = search(self.channels,self.channels)
            self.lateral_convs.append(l_conv)
            self.fpn_convs.append(fpn_conv)

        self.fpn_bottleneck = ConvModule(
             5*self.channels,
            self.channels,
            3,
            padding=1,
            conv_cfg=self.conv_cfg,
            norm_cfg=self.norm_cfg,
            act_cfg=self.act_cfg)
        self.upsample = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True)
        self.upsample4=nn.Upsample(scale_factor=4, mode='bilinear', align_corners=True)
        self.upsample8 = nn.Upsample(scale_factor=8, mode='bilinear', align_corners=True)
        self.compress_out = BasicConv(1024, 512, kernel_size=8, stride=8, padding=2)
        self.compress_out2 = BasicConv(1024, 512, kernel_size=1)
        self.my=My(self.channels,self.channels)
    def _forward_feature(self, inputs):
        """Forward function for feature maps before classifying each pixel with
        ``self.cls_seg`` fc.

        Args:
            inputs (list[Tensor]): List of multi-level img features.

        Returns:
            feats (Tensor): A tensor of shape (batch_size, self.channels,
                H, W) which is feature map for last layer of decoder head.
        """
        inputs = self._transform_inputs(inputs)

        # build laterals
        laterals = [
            lateral_conv(inputs[i])
            for i, lateral_conv in enumerate(self.lateral_convs)
        ]

        #laterals.append(self.psp_forward(inputs))

        # build top-down path
        used_backbone_levels = len(laterals)
        for i in range(used_backbone_levels - 1, 0, -1):
            prev_shape = laterals[i - 1].shape[2:]
            laterals[i - 1] = laterals[i - 1] + resize(
                laterals[i],
                size=prev_shape,
                mode='bilinear',
                align_corners=self.align_corners)

        # build outputs
        fpn_outs = [
            self.fpn_convs[i](laterals[i])
            for i in range(used_backbone_levels - 1)
        ]
        # append psp feature
        fpn_outs.append(laterals[-1])


        #第零圈
        fpn0_1 = torch.cat([self.upsample8(fpn_outs[3]), fpn_outs[0]], dim=1)
        fpn0_11 = self.compress_out(fpn0_1)
        fpn0_2 = torch.cat([self.upsample(fpn0_11), fpn_outs[2]], dim=1)
        fpn0_21 = self.compress_out2(fpn0_2)
        fpn0_3 = torch.cat([self.upsample(fpn0_21), fpn_outs[1]], dim=1)
        fpn0_31 = self.compress_out2(fpn0_3)
        fpn0_4 = torch.cat([self.upsample(fpn0_31), fpn_outs[0]], dim=1)
        fpn0_41 = self.compress_out2(fpn0_4)

        #第一圈
        fpn1_1 = torch.cat([self.upsample8(fpn_outs[3]), fpn0_41], dim=1)
        fpn1_11 = self.compress_out(fpn1_1)
        fpn1_2 = torch.cat([self.upsample(fpn1_11), fpn_outs[2]], dim=1)
        fpn1_21 = self.compress_out2(fpn1_2)
        fpn1_3 = torch.cat([self.upsample(fpn1_21), fpn_outs[1]], dim=1)
        fpn1_31 = self.compress_out2(fpn1_3)
        fpn1_4 = torch.cat([self.upsample(fpn1_31), fpn_outs[0]], dim=1)
        fpn1_41 = self.compress_out2(fpn1_4)

        #第二圈
        fpn2_1 = torch.cat([self.upsample8(fpn_outs[3]), fpn1_41], dim=1)
        fpn2_11 = self.compress_out(fpn2_1)
        fpn2_2 = torch.cat([self.upsample(fpn2_11), fpn_outs[2]], dim=1)
        fpn2_21 = self.compress_out2(fpn2_2)
        fpn2_3 = torch.cat([self.upsample(fpn2_21), fpn_outs[1]], dim=1)
        fpn2_31 = self.compress_out2(fpn2_3)
        fpn2_4 = torch.cat([self.upsample(fpn2_31), fpn_outs[0]], dim=1)
        fpn2_41 = self.compress_out2(fpn2_4)

        #第三圈
        fpn3_1 = torch.cat([self.upsample8(fpn_outs[3]), fpn2_41], dim=1)
        fpn3_11 = self.compress_out(fpn3_1)
        fpn3_2 = torch.cat([self.upsample(fpn3_11), fpn_outs[2]], dim=1)
        fpn3_21 = self.compress_out2(fpn3_2)
        fpn3_3 = torch.cat([self.upsample(fpn3_21), fpn_outs[1]], dim=1)
        fpn3_31 = self.compress_out2(fpn3_3)
        fpn3_4 = torch.cat([self.upsample(fpn3_31), fpn_outs[0]], dim=1)
        fpn3_41 = self.compress_out2(fpn3_4)

        fpn42 = fpn3_41
        fpn32=self.upsample(fpn3_31)
        fpn22=self.upsample4(fpn3_21)
        fpn12=self.upsample8(fpn3_11)
        fpnmy=self.my(laterals[0])
        fpn_outs = torch.cat([fpnmy,fpn42,fpn32,fpn22,fpn12],dim=1)
        feats = self.fpn_bottleneck(fpn_outs)
        return feats

    def forward(self, inputs):
        """Forward function."""
        output = self._forward_feature(inputs)
        output = self.cls_seg(output)
        return output


class search(nn.ModuleList):
    def __init__(self,in_ch,out_ch):
        super(search, self).__init__()
        mid_ch=512
        self.conv0=BasicConv(in_ch,mid_ch,3,1,1)
        self.conv11=BasicConv(mid_ch, mid_ch, kernel_size=(1, 7), padding=(0, 3))
        self.conv12 = BasicConv(mid_ch, mid_ch, kernel_size=(7, 1), padding=(3, 0))
        self.conv21 = BasicConv(mid_ch, mid_ch, kernel_size=(1, 5), padding=(0, 2))
        self.conv22 = BasicConv(mid_ch, mid_ch, kernel_size=(5, 1), padding=(2, 0))
        self.conv31 = BasicConv(mid_ch, mid_ch, kernel_size=(1, 3), padding=(0, 1))
        self.conv32 = BasicConv(mid_ch, mid_ch, kernel_size=(3, 1), padding=(1, 0))
        self.sconv1 = My_DSConv(mid_ch, mid_ch,3)
        self.sconv2 = My_DSConv(mid_ch, mid_ch, 3)
        self.sconv3 = My_DSConv(mid_ch, mid_ch, 3)
        self.conv4=BasicConv(mid_ch,out_ch,3,1,1)
    def forward(self, x):
        x0=self.conv0(x)
        x11=self.conv11(x0)
        x12=self.conv12(x11)
        x1=self.sconv1(x12)
        x21 = self.conv21(x0)
        x22 = self.conv22(x21)
        x2= self.sconv2(x22+x1)
        x31=self.conv31(x0)
        x32=self.conv32(x31)
        x3=self.sconv3(x32+x2)
        output=self.conv4(x1+x2+x3)
        return output



class My(nn.ModuleList):
    def __init__(self,in_ch,out_ch):
        super(My, self).__init__()
        mid_ch=in_ch//4
        self.conv0 = BasicConv(in_ch, mid_ch, 3, 1, 1)
        self.conv1 = BasicConv(in_ch, mid_ch, 5, 1,padding=2)
        self.conv2 = BasicConv(in_ch, mid_ch, 7, 1, 3)
        self.conv3 = BasicConv(in_ch, mid_ch, 9, 1, 4)
        self.conv4 = BasicConv(2, 1, 1)
        self.relu=nn.ReLU()
        self.sig=nn.Sigmoid()


    def forward(self,x):
        x1=self.conv0(x)
        x2=self.conv1(x)
        x3=self.conv2(x)
        x4=self.conv3(x)
        x20=torch.cat([x1,x2,x3,x4],dim=1)
        x_maxpool, _ = torch.max(x, dim=1, keepdim=True)
        x_avgpool = torch.mean(x, dim=1, keepdim=True)
        x_weight = torch.cat([x_maxpool, x_avgpool], dim=1)
        x_weight0=self.conv4(x_weight)
        x_out=x20*x_weight0
        return x_out

class BasicConv(nn.Module):

    def __init__(self, in_planes, out_planes, kernel_size, stride=1, padding=0, dilation=1, groups=1, relu=True, bn=True, bias=False):
        super(BasicConv, self).__init__()
        self.out_channels = out_planes
        self.conv = nn.Conv2d(in_planes, out_planes, kernel_size=kernel_size, stride=stride, padding=padding, dilation=dilation, groups=groups, bias=bias)
        self.bn = nn.BatchNorm2d(out_planes,eps=1e-5, momentum=0.01, affine=True) if bn else None
        self.relu = nn.ReLU(inplace=True) if relu else None

    def forward(self, x):
        x = self.conv(x)
        if self.bn is not None:
            x = self.bn(x)
        if self.relu is not None:
            x = self.relu(x)
        return x